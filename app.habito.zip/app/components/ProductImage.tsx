import React from "react";

function ProductImage() {
  return (
    <div className="col-md-6" style={{ display: "grid", placeItems: "center" }}>
      <img src="device.png" width="30%" />
    </div>
  );
}

export default ProductImage;
