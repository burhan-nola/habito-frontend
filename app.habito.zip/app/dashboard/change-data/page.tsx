import FormEditData from "@/app/components/FormEditData";
import React from "react";

const ChangeData = () => {
  return <FormEditData />;
};

export default ChangeData;
