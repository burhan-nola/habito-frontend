import FormEditTask from "@/app/components/FormEditTask";
import React from "react";

const ChangeTask = () => {
  return <FormEditTask />;
};

export default ChangeTask;
