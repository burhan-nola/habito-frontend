const evenNumber = [];
for (i = 0; i <= 100; i++) {
  if (i % 2 === 0) {
    evenNumber.push(i);
  }
}
